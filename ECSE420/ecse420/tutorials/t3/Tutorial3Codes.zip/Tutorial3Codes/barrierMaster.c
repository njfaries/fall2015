
#include <omp.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>

int main () {

  struct timeval start, end; // struct used to compute execution time	

 #pragma omp parallel num_threads(5) 
 { 
   
   #pragma omp barrier
   #pragma omp master
   gettimeofday(&start, NULL);  // set starting point
   
   #pragma omp critical   
   {
     if (omp_get_thread_num() == 4)
     {  sleep(4); }
     else
     {  sleep(2); }  
   }

    #pragma omp barrier
    #pragma omp master
    {  
      gettimeofday(&end, NULL);  // set ending point
      printf("\nAlgorithm's computational part duration : %ld\n\n", \
                   ((end.tv_sec) - (start.tv_sec)));
    }
 } 
 
 printf("\n\n");
 return 0;
}
