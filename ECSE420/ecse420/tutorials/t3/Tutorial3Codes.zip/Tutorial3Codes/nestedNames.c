
#include <omp.h>
#include <stdio.h>
#include <stdlib.h>

// main program
int main () {

 int threadID, threadID2;
 omp_set_nested(1);


 // let's print something
 printf("\nI'm the initial thread.\n");

 // initial (master) thread creates 3 more threads
 #pragma omp parallel num_threads(4)
 {
   // Get thread number
   threadID = omp_get_thread_num();
   printf("\tSection 1 - I'm thread %d\n", threadID);
 

   if (omp_get_thread_num()== 3){
    
     omp_set_num_threads(5);
     #pragma omp parallel
     { 
       threadID = omp_get_thread_num();
       printf("\tNested section - I'm thread %d\n", threadID);
     } // All threads join master thread and disband

   }

 } // All threads join master thread and disband

 printf("\nMaster thread - Here I am again\n");

 return 0;
}
