
#include <omp.h>
#include <stdio.h>
#include <stdlib.h>

// Array addition example
int main () {

 int a = 0;
 int b = 0;

 #pragma omp parallel num_threads(2)
 {
   // Thread 0 : 
   if (omp_get_thread_num()== 0)
      a = 2;
   
   // Thread 1 : 
   if (omp_get_thread_num()== 1)
      b = 2;

   #pragma omp flush(a,b)
   printf("Thread %d: a=%d,b=%d\n", omp_get_thread_num(), a, b );

 } 
 
 printf("\n\n");
 return 0;
}
