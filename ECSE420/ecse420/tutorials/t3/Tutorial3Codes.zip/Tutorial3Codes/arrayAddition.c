
#include <omp.h>
#include <stdio.h>
#include <stdlib.h>

// Array addition example
int main () {

 int i;
 int n = 5;
 int a[5] = {1,2,3,4,5}; 
 int b[5] = {1,2,3,4,5}; 
 int c[5];

 // independent loop iterations
 #pragma omp parallel for shared(n, a, b, c) private(i) num_threads(5)
 for (i = 0; i < n; i++)
     c[i] = a[i] + b[i];
 

 // verify that we are out of the critical section 
 // Get number of threads
 //printf("\nNumber of threads %d\n", omp_get_num_threads() );

 for (i = 0; i < n; i++)
   printf("c[i]=%d\n",c[i]);

 return 0;
}
