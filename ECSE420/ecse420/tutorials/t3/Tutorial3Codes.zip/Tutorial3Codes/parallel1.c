
#include <omp.h>
#include <stdio.h>
#include <stdlib.h>

// main program
int main () {

 int threadID;
 // initial (master) thread creates 3 more threads
 #pragma omp parallel num_threads(4)
 {
   // Get thread number
   threadID = omp_get_thread_num();
   printf("Parallel Section - I'm thread %d\n", threadID);
 } // All threads join master thread and disband

 return 0;
}
