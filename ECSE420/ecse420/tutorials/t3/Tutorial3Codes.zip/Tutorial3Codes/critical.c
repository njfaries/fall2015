
#include <omp.h>
#include <stdio.h>
#include <stdlib.h>

int main () {

 int TotalSum = 0;
 int mySum;

 #pragma omp parallel num_threads(5) shared(TotalSum) private(mySum) 
 {
   // different mySum values
   mySum = 4*omp_get_thread_num()-4;
   
   //#pragma omp critical
   TotalSum += mySum;
   //#pragma omp barrier
   printf("Thread %d - Total sum:%d\n", omp_get_thread_num(), TotalSum );

 } 
 
 printf("\n\n");
 return 0;
}
