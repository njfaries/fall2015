#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#define NUM_THREADS     2

int sharedVar;

void *thread1(void *t)
{
   int i;
   for (i=0;i<5;i++)
      sharedVar *=2;
   pthread_exit(NULL);
}

void *thread2(void *t)
{
   int i;
   for (i=0;i<10;i++)
      sharedVar -= 1;
   pthread_exit(NULL);
}


int main (int argc, char *argv[])
{
   pthread_t threads[NUM_THREADS];
   int rc;
   sharedVar = 5;
   long t;
   void *status;
   t = 0;
   rc = pthread_create(&threads[0], NULL, thread1, (void *)t);
   if (rc){
     printf("ERROR; return code from pthread_create() is %d\n", rc);
     exit(-1);
   }
   t = 1;
   rc = pthread_create(&threads[1], NULL, thread2, (void *)t);
   if (rc){
     printf("ERROR; return code from pthread_create() is %d\n", rc);
     exit(-1);
   }

   // wait for them to finish
   for(t=0; t<NUM_THREADS; t++) {
      rc = pthread_join(threads[t], &status);
      if (rc) {
         printf("ERROR; return code from pthread_join() is %d\n", rc);
         exit(-1);
         }
      }

   printf("shared variable=%d\n", sharedVar);

   /* Last thing that main() should do */
   pthread_exit(NULL);
}


