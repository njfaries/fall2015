
#include <omp.h>
#include <stdio.h>
#include <stdlib.h>

// Array addition example
int main () {

  int i;
  
  #pragma omp parallel private(i) num_threads(2) 
  { 
    #pragma omp for nowait 
    for (i = 0; i < 5; i++)
    {     
      sleep(omp_get_thread_num()*2);
    }
     // verify that thread 0 did not wait 
     printf("I am thread: %d\n", omp_get_thread_num() );
  }

 return 0;
}
